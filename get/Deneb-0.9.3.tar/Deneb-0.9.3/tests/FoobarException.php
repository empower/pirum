<?php

class FoobarException extends Exception
{
}
